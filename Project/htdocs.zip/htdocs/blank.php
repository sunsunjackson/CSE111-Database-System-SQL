<?php
echo '<img src="../aprfools.png" alt="This is the background" width="100%" height="100%">';
// echo "<style>
// 	body {
// 	  background-image: url('../aprfools.png');
// 	}
// 	</style>";
?>